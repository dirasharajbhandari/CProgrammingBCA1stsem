#include<stdio.h>
int main()
{
    int r=4,pie=3.14, area, perimeter;
   perimeter=2*pie*r,area=pie*r*r;
    printf("%d\n",area);
    printf("%d\n",perimeter);


}
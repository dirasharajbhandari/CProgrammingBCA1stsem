#include<stdio.h>
int main()
{
    int n,sum=0,rem,c;

    printf("enter the number:");
    scanf("%d",&c);

    n=c;
    while(n>0)
    {
        rem = n%10;
        sum = sum+rem*rem*rem;
         n = n/10;
     
    }
  

    if(sum==c)
    {
        printf("%d value is amstrong",c);
    
    }
    else
    {
        printf("%d value is not armstrong",c);

    }
}
